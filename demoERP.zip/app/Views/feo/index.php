<?php
/**
 * Контент страницы «Загрузка данных FEO» (TransportERP shell).
 * Вставляется в app/Views/layouts/main.php.
 *
 * СОХРАНЕНЫ ВСЕ JS-хуки: filterZayavki, searchText, showOnlyAvailable,
 * showOnlyMarshrut, showOnlyFlight, clearFilterBtn, clearSearchBtn,
 * filterStats, tableWrapper, dataTable, tableBody, loadingIndicator, noMoreData.
 */
?>
<!-- Page header -->
<div class="page-head">
    <div class="page-head-left">
        <div class="page-title">Загрузка данных FEO</div>
        <div class="page-summary">
            <span>Рабочая таблица заявок</span>
            <span class="sep">·</span>
            <span>автозагрузка</span>
        </div>
    </div>
</div>

<!-- Filter bar -->
<div class="filters-bar">
    <div class="filter-field" style="width: 280px;">
        <label for="filterZayavki">Фильтр по заявкам</label>
        <input type="text" id="filterZayavki" placeholder="Введите номера заявок через запятую, пробел" value="">
    </div>
    <div class="filter-field" style="width: 300px;">
        <label for="searchText">Поиск по содержимому</label>
        <input type="text" id="searchText" placeholder="Регион, МО, Отправитель, Адрес, Доступно, Маршрут, Рейс, Статус..." value="">
    </div>
    <div class="form-toggle">
        <label class="toggle-box"><input type="checkbox" id="showOnlyAvailable"> Готово к отгрузке</label>
        <label class="toggle-box"><input type="checkbox" id="showOnlyMarshrut"> Ставка согласована</label>
        <label class="toggle-box"><input type="checkbox" id="showOnlyFlight"> В работе</label>
    </div>
    <div class="filter-actions">
        <button id="clearFilterBtn" class="btn btn-toolbar">Очистить</button>
        <button id="clearSearchBtn" class="btn btn-toolbar">✕</button>
    </div>
</div>
<div id="filterInfo" style="padding: 2px 14px; font-size: 11px; color: var(--text-muted);"><span id="filterStats"></span></div>

<!-- Table card -->
<div class="table-card">
    <div class="table-toolbar">
        <div class="summary-left" id="summaryLeft">
            <span class="summary-main">
                <span class="summary-main-dot"></span>
                <span class="summary-main-label">Найдено:</span>
                <b id="foundCount">—</b>
                <span class="summary-main-unit">заявок</span>
            </span>
            <span id="loadingIndicator" style="display: none; font-size: 10px; font-weight: 700; color: var(--text-faint);">Загрузка...</span>
        </div>
        <div class="summary-right" id="statusSummary">
            <span class="summary-chip summary-chip-received">
                <span class="summary-chip-dot"></span>
                <span>Всего заявок получено</span>
                <b id="countReceived">—</b>
            </span>
            <span class="summary-chip summary-chip-planned">
                <span class="summary-chip-dot"></span>
                <span>Планируемый</span>
                <b id="countPlanned">—</b>
            </span>
            <span class="summary-chip summary-chip-found">
                <span class="summary-chip-dot"></span>
                <span>Рейс сформирован</span>
                <b id="countFound">—</b>
            </span>
            <span class="summary-chip summary-chip-started">
                <span class="summary-chip-dot"></span>
                <span>Вывоз начался</span>
                <b id="countStarted">—</b>
            </span>
            <span class="summary-chip summary-chip-completed">
                <span class="summary-chip-dot"></span>
                <span>Груз сдан</span>
                <b id="countCompleted">—</b>
            </span>
            <span class="summary-chip summary-chip-unprocessed">
                <span class="summary-chip-dot"></span>
                <span>Не обработано</span>
                <b id="countUnprocessed">—</b>
            </span>
        </div>
    </div>
    <div class="table-scroll" id="tableWrapper">
        <table class="table" id="dataTable">
            <colgroup>
                <col class="col-feo-id">
                <col class="col-feo-mass">
                <col class="col-feo-region">
                <col class="col-feo-mo">
                <col class="col-feo-sender">
                <col class="col-feo-address">
                <col class="col-feo-available">
                <col class="col-feo-route">
                <col class="col-feo-flight">
                <col class="col-feo-status">
                <col class="col-feo-date-from">
                <col class="col-feo-date-to">
                <col class="col-feo-price">
                <col class="col-feo-pricekg">
            </colgroup>
            <thead>
                <tr>
                    <th>ID ЗАЯВКИ</th>
                    <th style="text-align: right;">МАССА, КГ</th>
                    <th>МНО, РЕГИОН</th>
                    <th>МНО, МО</th>
                    <th>ГРУЗООТПРАВИТЕЛЬ</th>
                    <th style="text-align: left;">АДРЕС ПОГРУЗКИ</th>
                    <th style="text-align: center;">ОТГРУЗКА</th>
                    <th style="text-align: center;">СТАВКА</th>
                    <th style="text-align: center;">В РАБОТЕ</th>
                    <th style="text-align: center;">СТАТУС</th>
                    <th style="text-align: center;">ДАТА С</th>
                    <th style="text-align: center;">ДАТА ПО</th>
                    <th style="text-align: right;">СТОИМОСТЬ</th>
                    <th style="text-align: right;">₽/КГ</th>
                </tr>
            </thead>
            <tbody id="tableBody"></tbody>
        </table>
        <div id="noMoreData" class="no-more-data" style="display: none; text-align: center; padding: 1rem; color: var(--text-faint); font-size: 11px;">Все заявки загружены</div>
    </div>
</div>

<script>
var tableBody = document.getElementById('tableBody');
var tableWrapper = document.getElementById('tableWrapper');
var filterInput = document.getElementById('filterZayavki');
var clearFilterBtn = document.getElementById('clearFilterBtn');
var filterStats = document.getElementById('filterStats');
var loadingIndicator = document.getElementById('loadingIndicator');
var noMoreData = document.getElementById('noMoreData');
var showOnlyAvailableCheckbox = document.getElementById('showOnlyAvailable');
var showOnlyMarshrutCheckbox = document.getElementById('showOnlyMarshrut');
var showOnlyFlightCheckbox = document.getElementById('showOnlyFlight');

// Поиск по содержимому (СЕРВЕРНЫЙ)
var searchInput = document.getElementById('searchText');
var clearSearchBtn = document.getElementById('clearSearchBtn');

var currentOffset = 0;
var currentLimit = 50;
var currentFilter = '';
var currentTotal = 0;
var isLoading = false;
var hasMore = true;
var loadTimeout = null;
var scrollTimeout = null;
var searchTimeout = null;

function loadData(reset) {
    if (reset === undefined) reset = true;
    if (isLoading) return;
    if (reset) { currentOffset = 0; hasMore = true; tableBody.innerHTML = ''; noMoreData.style.display = 'none'; }
    if (!hasMore) return;
    isLoading = true;
    loadingIndicator.style.display = 'inline';

    var filterValue = filterInput.value.trim();
    var showOnlyAvailable = showOnlyAvailableCheckbox.checked ? '1' : '0';
    var showOnlyMarshrut = showOnlyMarshrutCheckbox.checked ? '1' : '0';
    var showOnlyFlight = showOnlyFlightCheckbox.checked ? '1' : '0';
    var contentSearch = searchInput ? searchInput.value.trim() : '';

    var url = '?module=feo&action=list&ajax=get_zayavki'
        + '&offset=' + currentOffset
        + '&limit=' + currentLimit
        + '&filter_zayavki=' + encodeURIComponent(filterValue)
        + '&content_search=' + encodeURIComponent(contentSearch)
        + '&show_only_available=' + showOnlyAvailable
        + '&show_only_marshrut=' + showOnlyMarshrut
        + '&show_only_flight=' + showOnlyFlight;

    fetch(url)
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                if (reset) {
                    tableBody.innerHTML = data.html;
                } else {
                    tableBody.insertAdjacentHTML('beforeend', data.html);
                }
                currentTotal = data.total;
                currentFilter = filterValue;
                hasMore = data.has_more;

                var rowsCount = tableBody.querySelectorAll('tr').length;
                currentOffset = rowsCount;

                if (!hasMore && currentOffset > 0) {
                    noMoreData.style.display = 'block';
                } else {
                    noMoreData.style.display = 'none';
                }

                updateFilterInfo(data);
                updateFoundLabel(data);
            } else {
                tableBody.innerHTML = '<tr><td colspan="14" style="text-align: center; padding: 40px; color: var(--danger);">Ошибка: ' + escapeHtml(data.message) + '</td></tr>';
            }
        })
        .catch(function(error) {
            console.error('Ошибка загрузки:', error);
            tableBody.innerHTML = '<tr><td colspan="14" style="text-align: center; padding: 40px; color: var(--danger);">Ошибка загрузки данных</td></tr>';
        })
        .finally(function() {
            isLoading = false;
            loadingIndicator.style.display = 'none';
        });
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>]/g, function(m) {
        if (m === '&') return '&';
        if (m === '<') return '<';
        if (m === '>') return '>';
        return m;
    });
}

function updateFoundLabel(data) {
    var fc = document.getElementById('foundCount');
    if (fc) fc.textContent = data.total;
    var cr = document.getElementById('countReceived');
    if (cr && data.status_counts) cr.textContent = data.status_counts.received_total || 0;
    var sc = data.status_counts || {};
    var cp = document.getElementById('countPlanned');
    if (cp) cp.textContent = sc.planned || 0;
    var cf = document.getElementById('countFound');
    if (cf) cf.textContent = sc.found || 0;
    var cs = document.getElementById('countStarted');
    if (cs) cs.textContent = sc.started || 0;
    var cc = document.getElementById('countCompleted');
    if (cc) cc.textContent = sc.completed || 0;
    var cu = document.getElementById('countUnprocessed');
    if (cu) cu.textContent = sc.unprocessed_total || 0;
}

function updateFilterInfo(data) {
    var filterText = [];
    if (data.show_only_available) filterText.push('доступные');
    if (data.show_only_marshrut) filterText.push('маршруты');
    if (data.show_only_flight) filterText.push('рейсы');
    var availableText = filterText.length > 0 ? ' (только ' + filterText.join(', ') + ')' : '';

    if (data.has_filter && data.filter_count > 0) {
        if (data.total > 0) {
            var message = 'Найдено заявок' + availableText + ': ' + data.total + ' из ' + data.filter_count + ' введенных';
            if (data.missing_zayavki && data.missing_zayavki.length > 0) {
                message += ' <span style="color: var(--danger);">: ' + escapeHtml(data.missing_zayavki.join(', ')) + '</span>';
            }
            filterStats.innerHTML = message;
        } else {
            var message2 = 'По введенным номерам заявок' + availableText + ' (' + data.filter_count + ') ничего не найдено';
            if (data.missing_zayavki && data.missing_zayavki.length > 0) {
                message2 += ' <span style="color: var(--danger);">: ' + escapeHtml(data.missing_zayavki.join(', ')) + '</span>';
            }
            filterStats.innerHTML = message2;
        }
    } else if (data.has_filter && data.filter_count === 0) {
        filterStats.innerHTML = 'Не найдено корректных номеров заявок';
    } else {
        filterStats.innerHTML = '';
    }
}

function handleScroll() {
    if (!tableWrapper) return;
    if (scrollTimeout) clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(function() {
        var scrollTop = tableWrapper.scrollTop;
        var scrollHeight = tableWrapper.scrollHeight;
        var clientHeight = tableWrapper.clientHeight;
        if (scrollTop + clientHeight >= scrollHeight - 100) {
            if (!isLoading && hasMore) loadData(false);
        }
    }, 100);
}

function handleFilterInput() {
    if (loadTimeout) clearTimeout(loadTimeout);
    loadTimeout = setTimeout(function() {
        loadData(true);
        if (tableWrapper) tableWrapper.scrollTop = 0;
    }, 500);
}

function handleCheckboxChange() {
    if (loadTimeout) clearTimeout(loadTimeout);
    loadTimeout = setTimeout(function() {
        loadData(true);
        if (tableWrapper) tableWrapper.scrollTop = 0;
    }, 300);
}

function clearFilter() {
    filterInput.value = '';
    showOnlyAvailableCheckbox.checked = false;
    showOnlyMarshrutCheckbox.checked = false;
    showOnlyFlightCheckbox.checked = false;
    loadData(true);
    if (tableWrapper) tableWrapper.scrollTop = 0;
}

// Серверный поиск по содержимому: debounce 500ms, сброс offset, AJAX reload
function handleSearchInput() {
    if (searchTimeout) clearTimeout(searchTimeout);
    searchTimeout = setTimeout(function() {
        loadData(true);
        if (tableWrapper) tableWrapper.scrollTop = 0;
    }, 500);
}

function clearSearch() {
    searchInput.value = '';
    loadData(true);
    if (tableWrapper) tableWrapper.scrollTop = 0;
}

// Event listeners
if (filterInput) filterInput.addEventListener('input', handleFilterInput);
if (clearFilterBtn) clearFilterBtn.addEventListener('click', clearFilter);
if (showOnlyAvailableCheckbox) showOnlyAvailableCheckbox.addEventListener('change', handleCheckboxChange);
if (showOnlyMarshrutCheckbox) showOnlyMarshrutCheckbox.addEventListener('change', handleCheckboxChange);
if (showOnlyFlightCheckbox) showOnlyFlightCheckbox.addEventListener('change', handleCheckboxChange);
if (searchInput) searchInput.addEventListener('input', handleSearchInput);
if (clearSearchBtn) clearSearchBtn.addEventListener('click', clearSearch);

// Бесконечная прокрутка
if (tableWrapper) {
    tableWrapper.addEventListener('scroll', handleScroll);
    var observer = new MutationObserver(function() {
        setTimeout(function() {
            if (tableWrapper.scrollHeight <= tableWrapper.clientHeight && hasMore && !isLoading) {
                loadData(false);
            }
        }, 100);
    });
    observer.observe(tableBody, { childList: true, subtree: true });
}

// Первая загрузка
loadData(true);
</script>
